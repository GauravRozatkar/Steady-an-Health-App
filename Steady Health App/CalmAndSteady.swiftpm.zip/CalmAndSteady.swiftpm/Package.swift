// swift-tools-version: 6.0

// This manifest follows the standard Swift Playgrounds App Playground layout.
// Swift 5 language mode is used on purpose: the audio render callback and the
// CoreHaptics handlers run on system threads, and Swift 5 mode keeps those
// bridges simple and predictable.

import PackageDescription
import AppleProductTypes

let package = Package(
    name: "Calm and Steady",
    platforms: [
        .iOS("18.0")
    ],
    products: [
        .iOSApplication(
            name: "Calm and Steady",
            targets: ["AppModule"],
            displayVersion: "1.0",
            bundleVersion: "1",
            appIcon: .placeholder(icon: .heart),
            accentColor: .presetColor(.green),
            supportedDeviceFamilies: [
                .pad,
                .phone
            ],
            supportedInterfaceOrientations: [
                .portrait,
                .landscapeRight,
                .landscapeLeft,
                .portraitUpsideDown(.when(deviceFamilies: [.pad]))
            ]
        )
    ],
    targets: [
        .executableTarget(
            name: "AppModule",
            path: "."
        )
    ],
    swiftLanguageVersions: [.v5]
)
